import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { toPublicPath } from '@/utils/assetPath';
import { Link, router, usePage } from '@inertiajs/react';
import { useEffect, useState } from 'react';
import Swal from 'sweetalert2';

export default function Index({ auth, products, filters }) {
    const roleID = usePage().props.auth.user.role_id;
    const isAdmin = roleID === 1; // Only allow actions for users with roleID 1
    const [searchTerm, setSearchTerm] = useState(filters.search || '');
    const { flash, errors } = usePage().props;
    const [selectedIds, setSelectedIds] = useState([]);

    const canDelete = auth.user.permissions.includes('PRODUCT_DELETE') || isAdmin;

    // Handle flash messages and automatic downloads
    useEffect(() => {
        // Check for download URL (from bulk upload) - handle this first
        if (flash?.download_url) {
            const successMsg = flash?.success || 'Upload completed.';
            const hasErrors = errors?.error;

            Swal.fire({
                icon: hasErrors ? 'warning' : 'success',
                title: hasErrors ? 'Import Completed with Errors' : 'Import Successful!',
                html: `
                    <p>${hasErrors ? errors.error : successMsg}</p>
                    <p class="mt-3"><strong>Click the button below to download the result file:</strong></p>
                `,
                showCancelButton: true,
                confirmButtonText: 'Download Result File',
                cancelButtonText: 'Close',
                confirmButtonColor: '#10B981',
            }).then((result) => {
                if (result.isConfirmed) {
                    // Open download URL
                    window.open(flash.download_url, '_blank');
                }
            });
            return; // Don't show other alerts if we showed this one
        }

        // Check for success message (without download)
        if (flash?.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: flash.success,
                confirmButtonText: 'OK',
            });
        }

        // Check for error messages (without download)
        if (errors?.error && !flash?.download_url) {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: errors.error,
                confirmButtonText: 'OK',
            });
        }
    }, [flash, errors]);

    // Reset selections when page data changes
    useEffect(() => {
        setSelectedIds([]);
    }, [products.data]);

    // Debug pagination data
    console.log('Pagination data:', {
        total: products.total,
        perPage: products.per_page,
        currentPage: products.current_page,
        lastPage: products.last_page,
        links: products.links
    });

    // Handle search with pagination
    const handleSearch = (e) => {
        e.preventDefault();
        router.get(
            route('products.index'),
            { search: searchTerm },
            { preserveState: true }
        );
    };

    // Checkbox handlers
    const toggleSelectAll = () => {
        if (selectedIds.length === products.data.length) {
            setSelectedIds([]);
        } else {
            setSelectedIds(products.data.map(p => p.id));
        }
    };

    const toggleSelectOne = (id) => {
        setSelectedIds(prev =>
            prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
        );
    };

    const isAllSelected = products.data.length > 0 && selectedIds.length === products.data.length;

    // Handle bulk delete
    const handleBulkDelete = () => {
        Swal.fire({
            title: 'Are you sure?',
            text: `You are about to delete ${selectedIds.length} product(s). This cannot be undone!`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: `Yes, delete ${selectedIds.length} product(s)!`
        }).then((result) => {
            if (result.isConfirmed) {
                router.post(route('products.bulk-destroy'), { ids: selectedIds }, {
                    onSuccess: () => {
                        setSelectedIds([]);
                    },
                    onError: () => {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Failed to delete selected products.',
                            confirmButtonText: 'OK',
                        });
                    }
                });
            }
        });
    };

    // Handle delete function
    const handleDelete = (productId) => {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                router.delete(route('products.destroy', productId), {
                    onSuccess: () => {
                        Swal.fire({
                            icon: 'success',
                            title: 'Deleted!',
                            text: 'Product has been deleted.',
                            confirmButtonText: 'OK',
                        });
                    },
                    onError: (errors) => {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Failed to delete product.',
                            confirmButtonText: 'OK',
                        });
                    }
                });
            }
        });
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                (auth.user.permissions.includes('PRODUCT_CREATE') || isAdmin) && (
                    <div className="flex justify-between items-center">
                        <h2 className="font-semibold text-xl text-gray-800 leading-tight">Products</h2>
                        <div className="flex space-x-4">
                            <Link
                                href={route('products.bulk-upload')}
                                className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 focus:bg-green-600 transition-colors"
                            >
                                Bulk Upload
                            </Link>
                            <Link
                                href={route('products.create')}
                                className="px-4 py-2 bg-[#7267ef] text-white rounded-lg hover:bg-[#6357df] focus:bg-[#6357df] transition-colors"
                            >
                                Add Product
                            </Link>
                        </div>
                    </div>
                )
            }
        >
            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 bg-white border-b border-gray-200">
                            {/* Search & Bulk Actions Bar */}
                            <div className="flex items-center justify-between mb-6 gap-4">
                                <form onSubmit={handleSearch} className="flex flex-1">
                                    <input
                                        type="text"
                                        placeholder="Search products..."
                                        className="w-full px-4 py-2 rounded-l-lg border border-gray-300 focus:border-[#7267ef] focus:ring focus:ring-[#7267ef] focus:ring-opacity-50"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                    <button
                                        type="submit"
                                        className="px-4 py-2 bg-[#7267ef] text-white rounded-r-lg hover:bg-[#6357df] focus:bg-[#6357df] transition-colors"
                                    >
                                        Search
                                    </button>
                                </form>

                                {/* Bulk Delete Button */}
                                {canDelete && selectedIds.length > 0 && (
                                    <button
                                        onClick={handleBulkDelete}
                                        className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors whitespace-nowrap"
                                    >
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                        </svg>
                                        Delete ({selectedIds.length})
                                    </button>
                                )}
                            </div>

                            {/* Selected count banner */}
                            {selectedIds.length > 0 && (
                                <div className="mb-4 px-4 py-2 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-between">
                                    <span className="text-sm text-blue-700 font-medium">
                                        {selectedIds.length} product(s) selected on this page
                                    </span>
                                    <button
                                        onClick={() => setSelectedIds([])}
                                        className="text-sm text-blue-600 hover:text-blue-800 underline"
                                    >
                                        Clear selection
                                    </button>
                                </div>
                            )}

                            {/* Products Table */}
                            <div className="overflow-x-auto">
                                <table className="min-w-full divide-y divide-gray-200">
                                    <thead className="bg-gray-50">
                                        <tr>
                                            {canDelete && (
                                                <th className="px-4 py-3 text-left">
                                                    <input
                                                        type="checkbox"
                                                        checked={isAllSelected}
                                                        onChange={toggleSelectAll}
                                                        className="rounded border-gray-300 text-[#7267ef] focus:ring-[#7267ef] cursor-pointer"
                                                        title="Select all on this page"
                                                    />
                                                </th>
                                            )}
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Name
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Category
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Image
                                            </th>
                                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Actions
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody className="bg-white divide-y divide-gray-200">
                                        {products.data.map((product) => (
                                            <tr
                                                key={product.id}
                                                className={`hover:bg-gray-50 ${selectedIds.includes(product.id) ? 'bg-blue-50' : ''}`}
                                            >
                                                {canDelete && (
                                                    <td className="px-4 py-4">
                                                        <input
                                                            type="checkbox"
                                                            checked={selectedIds.includes(product.id)}
                                                            onChange={() => toggleSelectOne(product.id)}
                                                            className="rounded border-gray-300 text-[#7267ef] focus:ring-[#7267ef] cursor-pointer"
                                                        />
                                                    </td>
                                                )}
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm font-medium text-gray-900">
                                                        {product.title}
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    <div className="text-sm font-medium text-gray-900">
                                                        {product.category ? product.category.name : 'No Category'}
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                    {product.image && (
                                                        <img
                                                            src={toPublicPath(`/storage/${product.image}`)}
                                                            alt={product.title}
                                                            className="w-16 h-16 object-cover"
                                                        />
                                                    )}
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                    <div className="flex items-center space-x-4">
                                                        {(auth.user.permissions.includes('PRODUCT_EDIT') || isAdmin) && (
                                                            <Link
                                                                href={route('products.edit', {
                                                                    product: product.id,
                                                                    search: filters.search || undefined,
                                                                    page: products.current_page,
                                                                })}
                                                                className="text-[#7267ef] hover:text-[#6357df]"
                                                            >
                                                                Edit
                                                            </Link>
                                                        )}

                                                        {canDelete && (
                                                            <button
                                                                onClick={() => handleDelete(product.id)}
                                                                className="text-red-600 hover:text-red-900"
                                                            >
                                                                Delete
                                                            </button>
                                                        )}

                                                        {(!auth.user.permissions.includes('PRODUCT_EDIT') && !auth.user.permissions.includes('PRODUCT_DELETE') && !isAdmin) && (
                                                            <span className="text-gray-500">Actions disabled</span>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>

                                {/* Empty State */}
                                {products.data.length === 0 && (
                                    <div className="text-center py-10">
                                        <p className="text-gray-500">No products found</p>
                                    </div>
                                )}
                            </div>

                            {/* Pagination */}
                            {products.links && products.links.length > 0 && (
                                <div className="mt-6">
                                    <div className="flex items-center justify-between">
                                        <div className="flex-1 flex justify-between sm:hidden">
                                            {/* Mobile pagination */}
                                            {products.prev_page_url && (
                                                <Link
                                                    href={products.prev_page_url}
                                                    className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                                                    preserveScroll
                                                    preserveState
                                                >
                                                    Previous
                                                </Link>
                                            )}
                                            {products.next_page_url && (
                                                <Link
                                                    href={products.next_page_url}
                                                    className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                                                    preserveScroll
                                                    preserveState
                                                >
                                                    Next
                                                </Link>
                                            )}
                                        </div>
                                        <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                                            <div>
                                                <p className="text-sm text-gray-700">
                                                    Showing <span className="font-medium">{products.from}</span> to{' '}
                                                    <span className="font-medium">{products.to}</span> of{' '}
                                                    <span className="font-medium">{products.total}</span> results
                                                </p>
                                            </div>
                                            <div>
                                                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                                                    {/* First Page Link */}
                                                    {products.current_page > 1 && (
                                                        <Link
                                                            href={products.first_page_url}
                                                            className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                                                            preserveScroll
                                                            preserveState
                                                        >
                                                            <span className="sr-only">First</span>
                                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                                                <path fillRule="evenodd" d="M15.707 15.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 010 1.414zm-6 0a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 011.414 1.414L5.414 10l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
                                                            </svg>
                                                        </Link>
                                                    )}

                                                    {/* Previous Page Link */}
                                                    {products.prev_page_url && (
                                                        <Link
                                                            href={products.prev_page_url}
                                                            className="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                                                            preserveScroll
                                                            preserveState
                                                        >
                                                            <span className="sr-only">Previous</span>
                                                            <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                                <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                                                            </svg>
                                                        </Link>
                                                    )}

                                                    {/* Page Links */}
                                                    {products.links.map((link, i) => {
                                                        // Skip first and last links (prev/next) as we handle them separately
                                                        if (i === 0 || i === products.links.length - 1) {
                                                            return null;
                                                        }

                                                        return link.url ? (
                                                            <Link
                                                                key={i}
                                                                href={link.url}
                                                                className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${link.active
                                                                    ? 'z-10 bg-[#7267ef] border-[#7267ef] text-white'
                                                                    : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                                                                    }`}
                                                                dangerouslySetInnerHTML={{ __html: link.label }}
                                                                preserveScroll
                                                                preserveState
                                                            />
                                                        ) : (
                                                            <span
                                                                key={i}
                                                                className="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700"
                                                                dangerouslySetInnerHTML={{ __html: link.label }}
                                                            />
                                                        );
                                                    })}

                                                    {/* Next Page Link */}
                                                    {products.next_page_url && (
                                                        <Link
                                                            href={products.next_page_url}
                                                            className="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                                                            preserveScroll
                                                            preserveState
                                                        >
                                                            <span className="sr-only">Next</span>
                                                            <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                                <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                                                            </svg>
                                                        </Link>
                                                    )}

                                                    {/* Last Page Link */}
                                                    {products.current_page < products.last_page && (
                                                        <Link
                                                            href={products.last_page_url}
                                                            className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                                                            preserveScroll
                                                            preserveState
                                                        >
                                                            <span className="sr-only">Last</span>
                                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                                                <path fillRule="evenodd" d="M4.293 15.707a1 1 0 001.414 0l5-5a1 1 0 000-1.414l-5-5a1 1 0 00-1.414 1.414L8.586 10 4.293 14.293a1 1 0 000 1.414zm6 0a1 1 0 001.414 0l5-5a1 1 0 000-1.414l-5-5a1 1 0 00-1.414 1.414L15.586 10l-4.293 4.293a1 1 0 000 1.414z" clipRule="evenodd" />
                                                            </svg>
                                                        </Link>
                                                    )}
                                                </nav>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
